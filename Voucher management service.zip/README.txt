Zat Bogdan Andrei - 323CC
				README
   Am implementat clasa ArrayMap care extinde AbstractMap pentru inceput.
Aceasta are in interiorul ei o clasa ArrayMapEntry care 
contine un k-key si un V-value.Clasa CampaignVoucherMap va extinde
ArrayMap, iar timpurile generice vor deveni String si ArrayList<Voucher>
CampaignVoucherMap mai contine si functia addVoucher care adauga un 
Voucher la cheia v.email daca exista, iar daca nu creeaza o lista 
noua de vouchere cu cheia v.email.UserVoucherMap este asemanatoare cu 
CampaighVoucherMap, dar extinde ArrayMap<Integer, ArrayList<Voucher>.
   Clasa abstracta Voucher contine atributele unui Voucher si este 
extinsa de GiftVoucher si LoyalityVoucher, cele 2 tipuri de vouchere.
Clasa Campaign contine atributele unei campanii, printre care si 
un CampaignVoucherMap<String,ArrayList<Vouchere>> si o lista de
User, observers.Aceasta clasa implementeaza interfata Subject, iar
user implementeaza interfata Observer, comunicand astfel printre ele
si respectand observer pattern.Functia generateVoucher din Campaign 
parcurge toti observerii din campanie si testeaza daca exista vreunul
cu acelasi email ca cel primit ca parametru. daca da, se verifica ce
tip de voucher este, LoyalityVoucher sau GiftVoucher si se adauga in 
dictionar, CampaignVoucherMap-ul clasei, dar si in dictionarul de 
vouchere al userului respectiv.Userul este adaugat si el in lista de 
observeri. Functia redeemVoucher schimba statusul voucherului cu 
codul "code" in USED. notifyAllObservers va apela functia update din 
fiecare ubserver, adaugand o notificare in lista acestora de notificari.
Pe langa aceasta lista de notificari, clasa User mai contine si un
UserVoucherMap<Integer,ArrayList<Voucher>>.
   Clasa VMS contine o lista de campanii si o lista de Users si 
este instantiata folosind design pattern-ul Singleton.Functia 
updateCampaign modifica parametrii campaniei cu id-ul id dupa 
parametrii campaign-ului primit ca parametru, Asta doar in situatiile 
in care statusul campaniei este NEW sau STARTED si notifica toti 
observatorii. cancelCampaign schimpa statusul campaniei cu id-ul id 
in CANCELLED.
   In clasa test am folosit obiecte de timp Scanner pentru a citi din 
fisierul text, cu delimitatoarele ";" si "\n". Am folosit un switch 
pentru toate posibilitatile din events, citind din fisier in variabile 
pe care apoi le-am folosit in rezolvarea fiecarei cerinte din events.			