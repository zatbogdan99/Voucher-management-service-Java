import java.util.ArrayList;

enum UserType {
    ADMIN,GUEST;

}

public class User implements Observer{
    private int id;
    public String nume;
    public String email;
    public String parola;
    public UserType type;

    public User(int id, String nume, String email, String parola, String type) {
        this.id = id;
        this.nume = nume;
        this.email = email;
        this.parola = parola;
        if (type.compareTo("ADMIN") == 0)
            this.type = UserType.ADMIN;
        else
            this.type = UserType.GUEST;
    }

    public UserVoucherMap<Integer,ArrayList<Voucher>> dictionar;
    public ArrayList<Notification> lista_notificari = new ArrayList<>();
    public int getId() {
        return id;
    }

    @Override
    public void update(Notification notification) {
        lista_notificari.add(notification);
    }

    @Override
    public String toString() {
        return "User{" +
                "id=" + id +
                ", nume='" + nume + '\'' +
                ", email='" + email + '\'' +
                ", parola='" + parola + '\'' +
                ", type=" + type +
                '}';
    }
}
