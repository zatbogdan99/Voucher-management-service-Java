import java.time.LocalDateTime;

public class GiftVoucher extends Voucher{
    public double suma;

    public GiftVoucher(int id, String cod, String email, int id_campanie, float value) {
        this.id = id;
        this.cod = cod;
        this.email = email;
        this.id_campanie = id_campanie;
        this.suma = value;
    }
}
