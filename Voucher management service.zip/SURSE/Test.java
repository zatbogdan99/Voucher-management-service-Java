import java.io.File;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Scanner;

public class Test {
    public static void main(String[] args) throws Exception {
        VMS vms = new VMS();
        int nr_campanii, temp;

        LocalDateTime data, aux;
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
        Campaign campaign;

        File file = new File("C:\\Users\\Bogdan\\Desktop\\VMStests\\test00\\input\\campaigns.txt");
        Scanner s = new Scanner(file);
        s.useDelimiter(";|\n");
        nr_campanii = s.nextInt();
        String sir = s.next();
        data = LocalDateTime.parse(sir, formatter);

        int i = 1;
        while (s.hasNext()) {
            int idCampanie = s.nextInt();
            String nume_campanie = s.next();
            String descriereCampanie = s.next();
            LocalDateTime dataStart = LocalDateTime.parse(s.next(), formatter);
            LocalDateTime dataFinalizare = LocalDateTime.parse(s.next(), formatter);
            int nrTotalVouchere = s.nextInt();
            String strategyType = s.next();
            campaign = new Campaign(idCampanie, nume_campanie, descriereCampanie, dataStart, dataFinalizare, nrTotalVouchere);
            campaign.setStrategyType(strategyType);
            vms.addCampaign(campaign);
            i++;
        }
//        System.out.println(campaigns.get(1));

        User u;
        file = new File("C:\\Users\\Bogdan\\Desktop\\VMStests\\test00\\input\\users.txt");
        s = new Scanner(file);
        s.useDelimiter(";|\n");
        int nrUseri = s.nextInt();
        while (s.hasNext()) {
            int idUser = s.nextInt();
            String numeUser = s.next();
            String parolaUser = s.next();
            String emailUser = s.next();
            String typeUser = s.next();
            u = new User(idUser, numeUser, emailUser, parolaUser, typeUser);
            vms.getUsers().add(u);
        }
//        System.out.println(vms.getUsers().get(0));

        file = new File("C:\\Users\\Bogdan\\Desktop\\VMStests\\test00\\input\\events.txt");
        s = new Scanner(file);
        s.useDelimiter(";|\n");
        LocalDateTime data_curenta = LocalDateTime.parse(s.next(), formatter);
        int nr_eventuri = s.nextInt();

//        for (Campaign c:vms.getCampaigns()){
//            System.out.println(c);
//        }
//        for (User user:vms.getUsers()){
//            System.out.println(user);
//        }

        int campaignId;
        String campaignName;
        String campaignDescription;
        LocalDateTime startDate;
        LocalDateTime endDate;
        int buget;
        String strategy;
        String email;
        String voucherType;
        float value;
        String voucherId;
        LocalDateTime localDate;
        int userId;
        String degeaba;

        for (int var = 0;var < nr_eventuri;var++){
            userId = s.nextInt();
            String pt_switch = s.next();


            switch (pt_switch) {
                case "addCampaign":
                    campaignId = s.nextInt();
                    campaignName = s.next();
                    campaignDescription = s.next();
                    startDate = LocalDateTime.parse(s.next(), formatter);
                    endDate = LocalDateTime.parse(s.next(), formatter);
                    buget = s.nextInt();
                    strategy = s.next();
                    if (vms.getUsers().get(userId - 1).type.equals(UserType.ADMIN)) {
                        campaign = new Campaign(campaignId, campaignName, campaignDescription, startDate, endDate, buget);
                        campaign.setStrategyType(strategy);
                        vms.addCampaign(campaign);
                    }
                    break;
                case "editCampaign":
                    campaignId = s.nextInt();
                    campaignName = s.next();
                    campaignDescription = s.next();
                    startDate = LocalDateTime.parse(s.next(), formatter);
                    endDate = LocalDateTime.parse(s.next(), formatter);
                    buget = s.nextInt();
                    if (vms.getUsers().get(userId - 1).type.equals(UserType.ADMIN)) {
                        campaign = new Campaign(campaignId, campaignName, campaignDescription, startDate, endDate, buget);
                        vms.updateCampaign(campaignId, campaign);
                    }
                    Notification n = new Notification(data_curenta,campaignId,NotificationType.EDIT);
                    vms.getUsers().get(userId-1).update(n);
                    break;
                case "cancelCampaign":
                    campaignId = s.nextInt();
                    degeaba = s.next();
                    if (vms.getUsers().get(userId - 1).type.equals(UserType.ADMIN)) {
                        vms.cancelCampaign(campaignId);
                    }
                    Notification notification = new Notification(data_curenta,campaignId,NotificationType.CANCEL);
                    vms.getUsers().get(userId-1).update(notification);
                    break;
                case "generateVoucher":
                    campaignId = s.nextInt();
                    email = s.next();
                    voucherType = s.next();
                    value = s.nextFloat();
                    if (vms.getUsers().get(userId - 1).type.equals(UserType.ADMIN)) {
                        vms.getCampaign(campaignId).generateVoucher(email, voucherType, value);
                    }

                    break;
                case "redeemVoucher":
                    campaignId = s.nextInt();
                    voucherId = s.next();
                    localDate = LocalDateTime.parse(s.next(), formatter);
                    if (vms.getUsers().get(userId - 1).type.equals(UserType.ADMIN)) {
                        vms.getCampaign(campaignId).redeemVoucher(voucherId, localDate);
                    }
                    break;
                case "getVouchers":
                    ArrayList<ArrayList<Voucher>> lista = new ArrayList<>();
                    if (vms.getUsers().get(userId - 1).type.equals(UserType.GUEST)) {
                        System.out.println(vms.getUsers().get(userId - 1).dictionar);
                    }
                    break;
                case "getObservers":
                    campaignId = s.nextInt();
                    if (vms.getUsers().get(userId - 1).type.equals(UserType.ADMIN)) {
                        System.out.println(vms.getCampaign(campaignId).getObservers());
                    }
                    break;
                case "getNotifications":
                    if (vms.getUsers().get(userId - 1).type.equals(UserType.GUEST)) {
                        System.out.println(vms.getUsers().get(userId - 1).lista_notificari);
                    }
                    break;
                default:
                    System.out.println("Nu exista comanda asta");
            }

//        }
//        for (Campaign c:vms.getCampaigns()){
//            System.out.println(c);
//        }
        }
//        System.out.println(vms.getCampaign(1).getStatus());
    }
}
