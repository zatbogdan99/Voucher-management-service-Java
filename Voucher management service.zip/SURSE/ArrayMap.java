import java.util.*;
import java.util.concurrent.RecursiveTask;

public class ArrayMap<K,V> extends AbstractMap<K,V> {

        class ArrayMapEntry<K,V> implements Map.Entry<K,V>{
        K key;
        V value;

        public ArrayMapEntry(K key, V value){
            this.key = key;
            this.value = value;
        }

        @Override
        public K getKey() {
            return key;
        }

        @Override
        public V getValue() {
            return value;
        }

        @Override
        public V setValue(V value) {
            V temp = this.value;
            this.value = value;
            return temp;
        }

        @Override
        public String toString() {
            return "ArrayMapEntry{" +
                    "key2=" + key +
                    ", value=" + value +
                    '}';
        }

        @Override
        public boolean equals(Object o) {
            if (!(o instanceof ArrayMapEntry))
                return false;
            ArrayMapEntry<K, V> other = (ArrayMapEntry<K, V>) o;
            return (this.getKey()==null ?
                    other.getKey()==null : this.getKey().equals(other.getKey())  &&
                    (this.getValue()==null ?
                            other.getValue()==null : this.getValue().equals(other.getValue())));
        }

        @Override
        public int hashCode() {
            return  (this.getKey()==null   ? 0 : this.getKey().hashCode()) ^(this.getValue()==null ? 0 : this.getValue().hashCode());
        }
    }

        public ArrayList<ArrayMapEntry<K,V>> list = null;
        public Set<Map.Entry<K,V>> entries = null;

        public ArrayMap(){
            list = new ArrayList<>();
        }

        @Override
        public int size() {
            return list.size();
        }


       @Override
       public V put(K key, V value) {
            int i=0;
            Map.Entry<K,V> entry = null;
            if (key == null) {
                for (i = 0; i < size(); i++) {
                    entry = list.get(i);
                    if (entry.getKey() == null)
                        break;
                }
            }
            else{
                for (i=0; i<size(); i++){
                    entry = list.get(i);
                    if (key.equals(entry.getKey()))
                        break;
                }
            }
            V old = null;
            if (i < size()){
                old = entry.getValue();
                entry.setValue((V) value);
            }
            else{
                list.add(new ArrayMapEntry(key,value));
            }
            return old;
        }

        @Override
        public boolean containsKey(Object key) {
            for (int i=0; i<size() ; i++) {
                if (list.get(i).getKey().equals(key))
                    return true;
            }
            return false;
        }

        @Override
        public V get(Object key) {
           if (list.contains(key)) {
               for (int i = 0; i < size(); i++) {
                   if (list.get(i).equals(key))
                       return (V) list.get(i).getValue();
               }
           }
           return null;
        }

        @Override
        public Set<Entry<K,V>> entrySet() {
            if (entries == null) {
                entries = new AbstractSet<Entry<K, V>>() {
                    @Override
                    public Iterator iterator() {
                        return list.iterator();
                    }

                    @Override
                    public int size() {
                        return list.size();
                    }
                };
            }
        return entries;
        }

}
