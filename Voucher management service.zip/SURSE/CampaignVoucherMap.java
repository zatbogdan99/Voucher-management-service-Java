import java.util.ArrayList;

public class CampaignVoucherMap<K,V> extends ArrayMap<String, ArrayList<Voucher>> {

    public CampaignVoucherMap(){
        super();
    }

    public boolean addVoucher( Voucher v){
        if (containsKey(v.email))
        for (int i=0; i<size(); i++) {
            if (list.get(i).getKey().equals(v.email))
                super.list.get(i).value.add(v);
            } else {
                ArrayList<Voucher> listaNoua = new ArrayList<Voucher>();
                listaNoua.add(v);
                put(v.email, listaNoua);
            }
        return true;
        }
    }
