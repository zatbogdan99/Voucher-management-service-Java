import java.time.LocalDateTime;

enum VoucherStatusType {
    USED,UNUSED;
}

public abstract class Voucher {
    public int id;
    public String cod;
    public LocalDateTime data;
    public String email;
    public int id_campanie;
    public VoucherStatusType status = VoucherStatusType.UNUSED;
}
