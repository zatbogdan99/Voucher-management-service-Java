import java.util.ArrayList;

public class VMS {
    private ArrayList<Campaign> campanii = new ArrayList<>();
    private ArrayList<User> users = new ArrayList<>();
    private static VMS obj = null;

    public ArrayList<Campaign> getCampaigns() {
        return campanii;
    }

    public ArrayList<User> getUsers() {
        return users;
    }

    public static VMS getInstance(){
        if (obj == null)
            obj = new VMS();
        return obj;
    }
    public Campaign getCampaign(Integer id){
        for (Campaign c:campanii){
            if (c.getId_campanie() == id){
                return c;
            }
        }
        return null;
    }
    public void addCampaign(Campaign campaign){
        campanii.add(campaign);
    }
    public void updateCampaign(Integer id, Campaign campaign){
        for (Campaign c: campanii){
            if (c.getId_campanie() == id){
                if (c.getStatus().equals(CampaignStatusType.NEW)){
//                    c.dictionar = campaign.dictionar;
//                    c.observers = campaign.observers;
                    c.data_start = campaign.data_start;
                    c.data_finalizare = campaign.data_finalizare;
                    c.descriere_campanie = campaign.descriere_campanie;
                    c.nrTotalVouchere = campaign.nrTotalVouchere;
                    c.nume_campanie = campaign.nume_campanie;
                    Notification n = new Notification(c.data_finalizare,c.getId_campanie(),NotificationType.EDIT);
                    c.notifyAllObservers(n);
                }
                else
                    if (c.getStatus().equals(CampaignStatusType.STARTED) ){
                        c.nrTotalVouchere = campaign.nrTotalVouchere;
                        c.data_finalizare = campaign.data_finalizare;
                        Notification n = new Notification(c.data_finalizare,c.getId_campanie(),NotificationType.EDIT);
                        c.notifyAllObservers(n);
                    }
            }
        }
    }
    public void cancelCampaign(Integer id){
        for (Campaign c: campanii){
            if (c.getId_campanie() == id){
                if ((c.getStatus().equals(CampaignStatusType.NEW)) || (c.getStatus().equals((CampaignStatusType.STARTED)))){
                    c.setStatus(CampaignStatusType.CANCELLED);
                    Notification n = new Notification(c.data_finalizare,c.getId_campanie(),NotificationType.CANCEL);
                    c.notifyAllObservers(n);
                }
            }
        }

    }
    public void addUser(User user){
        if (users.contains(user)){
            users.add(user);
        }
    }
}
