import java.time.LocalDateTime;

public class LoyalityVoucher extends Voucher {
    public float reducere;

   public LoyalityVoucher(int id, String cod,String email,int id_campanie, float value){
       this.id = id;
       this.cod = cod;
       this.email = email;
       this.id_campanie = id_campanie;
        this.reducere = value;
   }
}
