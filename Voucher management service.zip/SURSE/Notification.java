import java.time.LocalDateTime;
import java.util.ArrayList;
enum NotificationType {
    EDIT,CANCEL;
}
public class Notification {

    public Notification(LocalDateTime data, int id_campanie, NotificationType type) {
        this.data = data;
        this.id_campanie = id_campanie;
        this.type = type;
    }

    public LocalDateTime data;
    public int id_campanie;
    public NotificationType type;
    public ArrayList<String> coduri = new ArrayList<>();

    @Override
    public String toString() {
        return "Notification{" +
                "data=" + data +
                ", id_campanie=" + id_campanie +
                ", type=" + type +
                '}';
    }
}
