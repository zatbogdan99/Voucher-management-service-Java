import java.time.LocalDateTime;
import java.util.ArrayList;

enum CampaignStatusType {
    NEW,STARTED,EXPIRED,CANCELLED;
}

public class Campaign implements Subject {

    private int id_campanie;
    public String nume_campanie;
    public String descriere_campanie;
    public LocalDateTime data_start;
    private String strategyType;

    public Campaign(int id_campanie, String nume_campanie, String descriere_campanie, LocalDateTime data_start, LocalDateTime data_finalizare, int nrTotalVouchere) {
        this.id_campanie = id_campanie;
        this.nume_campanie = nume_campanie;
        this.descriere_campanie = descriere_campanie;
        this.data_start = data_start;
        this.data_finalizare = data_finalizare;
        this.nrTotalVouchere = nrTotalVouchere;
        NumarCurentVouchereDisponibile = nrTotalVouchere;
        this.setStrategyType(strategyType);
        this.setStatus(CampaignStatusType.NEW);
    }

    public LocalDateTime data_finalizare;
    public int nrTotalVouchere;
    public int NumarCurentVouchereDisponibile;
    private int id_voucher=0;

    private CampaignStatusType status;
    public CampaignVoucherMap<String,ArrayList<Voucher>> dictionar = new CampaignVoucherMap<>();
    public ArrayList<User> observers = new ArrayList<User>();

    public CampaignStatusType getStatus() {
        return status;
    }

    public int getId_campanie() {
        return id_campanie;
    }

    public void setStrategyType(String strategyType) {
        this.strategyType = strategyType;
    }

    public void setNumarCurentVouchereDisponibile(int numarCurentVouchereDisponibile) {
        NumarCurentVouchereDisponibile = numarCurentVouchereDisponibile;
    }

    public void setNrTotalVouchere(int nrTotalVouchere) {
        this.nrTotalVouchere = nrTotalVouchere;
    }

    public void setId_campanie(int id_campanie) {
        this.id_campanie = id_campanie;
    }

    public void setNume_campanie(String nume_campanie) {
        this.nume_campanie = nume_campanie;
    }

    public void setDescriere_campanie(String descriere_campanie) {
        this.descriere_campanie = descriere_campanie;
    }

    public void setData_start(LocalDateTime data_start) {
        this.data_start = data_start;
    }

    public void setData_finalizare(LocalDateTime data_finalizare) {
        this.data_finalizare = data_finalizare;
    }

    public void setStatus(CampaignStatusType status) {
        this.status = status;
    }

    public CampaignVoucherMap<String,ArrayList<Voucher>> getVouchers(){
        return this.dictionar;
    }

    public Voucher getVoucher(String code){
        for (int i=0; i<dictionar.size(); i++)
            for (int j=0; j<dictionar.list.get(i).getValue().size(); j++)
                if (dictionar.list.get(i).getValue().get(j).cod.equals(code))
                    return dictionar.list.get(i).getValue().get(j);
        return null;
    }

    public void generateVoucher(String email, String voucherType, float value){
            if (NumarCurentVouchereDisponibile > 0)
            {
                for (User u:observers){
                    if (u.email.equals(email))
                        if (voucherType.equals("LoyalityVoucher")){
                            NumarCurentVouchereDisponibile--;
                            id_voucher++;
                            LoyalityVoucher voucher = new LoyalityVoucher(id_voucher,Integer.valueOf(id_voucher).toString(),email,id_campanie,value);
                            dictionar.addVoucher(voucher);
                            u.dictionar.addVoucher(voucher);
                            addObserver(u);
                        }
                    else {
                        NumarCurentVouchereDisponibile--;
                        id_voucher++;
                            GiftVoucher voucher = new GiftVoucher(id_voucher,Integer.valueOf(id_voucher).toString(),email,id_campanie,value);
                            dictionar.addVoucher(voucher);
                            u.dictionar.addVoucher(voucher);
                            addObserver(u);
                        }
                }
            }
        }

    public void redeemVoucher(String code, LocalDateTime date){
        for (int i=0 ; i<dictionar.size(); i++){
            for (int j=0; j<dictionar.get(i).size(); j++)
            if (dictionar.get(i).get(j).cod.equals(code)) {
                dictionar.get(i).get(j).status = VoucherStatusType.USED;
                dictionar.get(i).get(j).data = date;
            }
        }
    }

    public ArrayList<User> getObservers(){
        return observers;
    }

    @Override
    public void addObserver(User user) {
        if (NumarCurentVouchereDisponibile > 0)
            observers.add(user);
    }

    @Override
    public void removeObserver(User user) {
        if (observers.contains(user))
            observers.remove(user);
    }

    @Override
    public void notifyAllObservers(Notification notification) {
        for (int i=0; i<observers.size(); i++){
            observers.get(i).update(notification);
        }
    }

    @Override
    public String toString() {
        return "Campaign{" +
                "id_campanie=" + id_campanie +
                ", nume_campanie='" + nume_campanie + '\'' +
                ", descriere_campanie='" + descriere_campanie + '\'' +
                ", data_start=" + data_start +
                ", strategyType='" + strategyType + '\'' +
                ", data_finalizare=" + data_finalizare +
                ", nrTotalVouchere=" + nrTotalVouchere +
                ", NumarCurentVouchereDisponibile=" + NumarCurentVouchereDisponibile +
                '}';
    }
}
