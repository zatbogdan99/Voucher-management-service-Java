import java.util.ArrayList;

public class UserVoucherMap<K,V> extends ArrayMap<Integer, ArrayList<Voucher>> {
    public UserVoucherMap(){
        super();
    }
    public boolean addVoucher (Voucher v){
        if (containsKey(v.id_campanie))
            for (int i=0; i<size(); i++){
                if (list.get(i).getKey().equals(v.id_campanie))
                    list.get(i).getValue().add(v);
            }
        else{
            ArrayList<Voucher> listaNoua = new ArrayList<Voucher>();
            listaNoua.add(v);
            put(v.id_campanie, listaNoua);
        }
        return true;
    }
}
